<?php
// cron/gossip_peers.php - Cron Task: discover and manage peers

// This script is executed via run_cron.php
// Logic is now inside Node.php::doGossipPeers()
// No code needed here, run_cron.php handles execution.
// This file exists just for clarity of the cron structure.
?>