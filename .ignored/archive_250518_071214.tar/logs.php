<?php
    phpinfo();